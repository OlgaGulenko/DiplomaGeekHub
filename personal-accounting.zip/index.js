console.log([1, 2, 3].map(n => n + 1))
