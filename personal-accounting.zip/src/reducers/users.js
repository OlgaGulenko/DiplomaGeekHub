const initialState = [
    {
        email: "qwerty",
        password: "qwerty",
        id: 9
    }
];

function users(state = initialState, action) {
    return state;
}
